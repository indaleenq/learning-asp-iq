﻿using oopConceptsLibrary;
using System;

namespace oopConcepts
{
    class Program
    {
        static void Main(string[] args)
        {
            GradeBook cartneyGrades = new GradeBook();

            cartneyGrades.AddGrade(80);
            cartneyGrades.AddGrade(75);

            float finalGrade = cartneyGrades.CalculateGrade();

            Console.WriteLine("Cartney's Final Grade is " + finalGrade.ToString());

            cartneyGrades.PrintGrades();
        }
    }
}
