﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopConceptsLibrary
{
    public class Student
    {
        public string studentNumber;
        public string studentName;
        public int mathgrade;
        public int enggrade;

        public float CalculateGrade()
        {
            float avg = (mathgrade + enggrade) / 2;
            return avg;
        }
    }
}
