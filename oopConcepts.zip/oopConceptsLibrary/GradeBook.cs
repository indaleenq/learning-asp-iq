﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopConceptsLibrary
{
    public class GradeBook
    {
        private int index = 0;
        int[] grades = new int[5];

        public void AddGrade(int grade)
        {
            grades[index] = grade;
            index++;
        }
        
        public float CalculateGrade()
        {
            int sum = 0;

            foreach (var grade in grades)
            {
                sum += grade;
            }

            float avg = sum / (index);
            return avg;
        }

        public void PrintGrades()
        {
            foreach (var grade in grades)
            {
                Console.WriteLine(grade.ToString() + " ");
            }
        }

    }
}
