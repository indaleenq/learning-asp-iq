﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oopConceptsLibrary
{
    class Subject
    {
        Student student = new Student();
        
        public void GetStudent()
        {
            student.studentName = "Cartney";
        }
    }
}
